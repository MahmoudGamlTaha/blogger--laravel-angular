import { Component, Input } from '@angular/core';

import { Article, ArticleListConfig, ArticlesService } from '../../core';
@Component({
  selector: 'app-article-list',
  styleUrls: ['article-list.component.css'],
  templateUrl: './article-list.component.html'
})
export class ArticleListComponent {
  constructor (
    private articlesService: ArticlesService
  ) {}

  @Input() limit: number;
  @Input()
  set config(config: ArticleListConfig) {
    if (config) {
      this.query = config;
      this.currentPage = 1;
      this.runQuery();
    }
  }

  query: ArticleListConfig;
  results: Article[];
  loading = false;
  currentPage = 1;
  totalPages: Array<number> = [1];

  setPageTo(pageNumber) {
    this.currentPage = pageNumber;
    this.runQuery();
  }

  runQuery() {
    this.loading = true;
    this.results = [];

    // Create limit and offset filter (if necessary)
    if (this.limit) {
      this.query.filters.limit = this.limit;
      console.log("pages:"+this.currentPage);
      this.query.filters.offset =  (this.limit * (this.currentPage-1));
    }
    
    this.articlesService.query(this.query)
    .subscribe(data => {
      this.loading = false;
      data.articlesCount = data["posts"].length;
      this.results = data["posts"].slice( this.query.filters.offset, (this.limit  * (this.currentPage)% data.articlesCount));
      if(this.query.filters.tag)
      this.results = this.results.filter(s => s.category.name == this.query.filters.tag);
      this.totalPages = Array.from(new Array(Math.ceil(data.articlesCount / this.limit)), (val, index) => index + 1);
    });
  }
}
