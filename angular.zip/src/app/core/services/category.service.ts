import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from './api.service';
import { map } from 'rxjs/operators';
//import {} from '../core/models/category.model';

@Injectable()
export class CategoryService {
  
  constructor (
    private apiService: ApiService
  ) {}

  getAll(): Observable<[string]> {
    return this.apiService.get('/tags')
          .pipe(map(data => data.tags));
  }
  getAllCats(): Observable<[any]> {
    return this.apiService.get('/cats')
          .pipe(map(data => data.cats));
  }

}
