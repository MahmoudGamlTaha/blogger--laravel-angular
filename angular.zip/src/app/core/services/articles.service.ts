import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ApiService } from './api.service';
import { Article, ArticleListConfig } from '../models';
import { map } from 'rxjs/operators';

@Injectable()
export class ArticlesService {
  constructor (
    private apiService: ApiService
  ) {}

  query(config: ArticleListConfig): Observable<{articles: Article[], articlesCount: number}> {
    // Convert any filters over to Angular's URLSearchParams
    const params = {};

    Object.keys(config.filters)
    .forEach((key) => {
      params[key] = config.filters[key];
    });
console.log(params);
    return this.apiService
    .get(
      '/articles',
      new HttpParams({ fromObject: params })
    );
  }

  get(id): Observable<Article> {
    console.log("get article id:"+id);
    return this.apiService.get('/articles/' + id)
      .pipe(map(data => data.article));
  }

  destroy(slug) {
    return this.apiService.delete('/articles/' + slug);
  }

  save(article): Observable<Article> {
    // If we're updating an existing article
    if (article.id) {
      console.log("update");
      return this.apiService.put('/articles/' + article.id, {article: article})
        .pipe(map(data => data.article));

    // Otherwise, create a new article
    } else {
      console.log("create");
      return this.apiService.post('/articles/', {article: article})
        .pipe(map(data => data.article));
    }
  }

}
