import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ApiService } from './api.service';
import { Comment } from '../models';
import { map } from 'rxjs/operators';


@Injectable()
export class CommentsService {
  constructor (
    private apiService: ApiService
  ) {}

  add(slug, payload, uid): Observable<Comment> {
    return this.apiService
    .post(
      `/articles/${slug}/comment`,
      { comment: { body: payload, user_id:uid } }
    ).pipe(map(data => data.comment));
  }

  getAll(id): Observable<Comment[]> {
    return this.apiService.get(`/articles/${id}/comments`)
      .pipe(
        map(
          data => data.comments
          ));
  }

  destroy(commentId, article_id) {
    return this.apiService
           .delete(`/articles/${article_id}/comments/${commentId}`);
  }

}
