import { Profile } from './profile.model';
import {Category} from './category.model'
export interface Article {
  id:number;
  slug: string;
  title: string;
  description: string;
  body: string;
  created_At: string;
  updated_At: string;
  author: Profile;
  author_id: number;
  category_id:number;
  category:Category;

}
