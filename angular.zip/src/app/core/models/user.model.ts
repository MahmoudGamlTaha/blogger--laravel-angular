export interface User {
  id:number;
  role_id:number;
  email: string;
  token: string;
  username: string;
  bio: string;
  image: string;
}
