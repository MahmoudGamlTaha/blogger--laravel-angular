export const environment = {
  production: true,
  api_url: 'http://127.0.0.1:8000/api'
};
