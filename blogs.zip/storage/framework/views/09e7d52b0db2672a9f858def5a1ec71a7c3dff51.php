<html>
<head>
</head>
<body>
<h2>backend is up</h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\blogger\site\blogs\resources\views/welcome.blade.php ENDPATH**/ ?>