in frontend app folder 
run this two command
npm install
npm install --save @ng-select/ng-select
==============
in blogs folder 