<?php
namespace App\Http\Controllers;
use App\User;
use ILluminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller{
    use AuthenticatesUsers;
   
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    } 
    public function signup(Request $request)
    {
       // return  $request->input('username');
      $this->validate($request,
      ['name' =>'required|unique:users',
       'password' => 'required',
       'email' => 'required|unique:users'
       ]);
      $user = new User();
      $user->name = $request->input('name');
      $user->role_id = 2; //normal user
      $user->password = bcrypt($request->input('password')) ;
      $user->email = $request->input('email');
      $user->save();
      $response = ['user' => $user];
      return response()->json($response, 200);
  }
  
  public function signIn(Request $request )
  {
    $response = ['CSRF' => 'h'];
    return response()->json($response, 200);
  } 
}