<?php

namespace App\Http\Controllers;

use App\Categories;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Post;
class CategoryController extends Controller
{
   
    public function createCategory(Request $request)
    {
       $post = new Post();
   //    $post->author_id = $request->input("author_id");
       $post->body = $request->input("body");
       $post->meta_description = $request->input('meta_description');
       $post->title = $request->input("title");
       
       //$post->image = $request->input('pImg');
      // $post->status = $request->input('published');
       //$post->featured = $request->input('featured');
       $post->save();
       return response()->json(['post' => $post], 201);
    }
    public function editCategory(Request $request,$id)
    {
        $post = Post::find($id);
        if(!$post)
        {
            return response()->json(['message'=> 'key not found'], 404);
        }
        
        //return $request->input('post')
     // return  $request->input('title');
       // die;
     //   $post->author_id = $request->input("author_id");
        $post->body = $request->input("body");
        $post->title = $request->input("title");
        //$post->image = $request->input('pImg');
        //$post->status = $request->input('published');
       // $post->featured = $request->input('featured');
        $post->meta_description = $request->input('meta_description');
        $post->save();
        return response()->json(['post' => $post], 200);
    }

    public function deleteCategory($id)
    {
        $cat = Categories::find($id);
        if(!$cat)
        {
            return response()->json(['message'=> 'key not found'], 404);
        }
        $cat->delete();
        return response()->json(['message'=>'post deleted with title '.$cat->name], 200);
    }

    public function CategoryList()
    {
       // : Content-Type
      $cats = Categories::select('name')->pluck('name');
      $response = ['tags' => $cats];
      return response()->json($response, 200);
    }
    public function Categories()
    {
      $cats = Categories::all();
      return  $this->sendResponse($cats, '200','cats');
    }
}