<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Post;
class PostController extends Controller
{
   
    public function createPost(Request $request)
    {
       $postReq = $request->json()->all();
       $post = new Post();
       $post->body = $postReq["article"]["body"];
       $post->meta_description = $postReq["article"]["description"];
       $post->title = $postReq["article"]["title"];
	   $post->category_id = $postReq["article"]["category_id"];
       $post->save();
       return  $this->sendResponse($post,'200','article');// response()->json(['post' => $post], 201);
    }
    public function editPost(Request $request,$id)
    {
        $post = Post::find($id);
        if(!$post)
        {
            return response()->json(['message'=> 'key not found'], 404);
        }
        $postReq = $request->json()->all();
        $post->body = $postReq["article"]["body"];
        $post->meta_description = $postReq["article"]["meta_description"];
        $post->title = $postReq["article"]["title"];
	    $post->category_id = $postReq["article"]["category_id"];
        $post->save();
        return  $this->sendResponse($post,'200','article');
    }

    public function postDetail($id)
    {
        $post = Post::find($id);
        if(!$post)
        {
            return response()->json(['message'=> 'key not found'], 404);
        }
        return response()->json(['article' => $post], 200);
    }

    public function deletePost($id)
    {
        $post = Post::find($id);
        if(!$post)
        {
            return response()->json(['message'=> 'key not found'], 404);
        }
        $post->delete();
        return response()->json(['message'=>'post deleted with title '.$post->title], 200);
    }

    public function postList()
    {
      $posts = Post::with('category')->get(); 
      $response = ['posts' => $posts];
      return response()->json($response, 200);
    }
}