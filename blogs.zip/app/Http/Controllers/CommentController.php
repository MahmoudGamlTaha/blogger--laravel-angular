<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Log;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use App\Comment;
class CommentController extends Controller
{

  public function  addcomment(Request $request, $id)
  {
    $data= $request->json()->all();
      Log::info($data);
      $comment = new Comment();
      $comment->post_id = $id;
      $comment->body = $data["comment"]["body"];
      $comment->user_id = $data["comment"]["user_id"];
      $comment->save();
      return $this->sendResponse($comment,'200');
  }
  public function getComments($postId)
  {
      $comments = Comment::where('post_id', $postId)->get();     
      return $this->sendResponse($comments,'201','comments');
  }

  public function deleteComment(Request $request, $id, $comment_id)
  {
    $data= $request->json()->all();
      
      $comment = new Comment();
      $comment->id = $comment_id;
      $comment->post_id = $id;
      $comment->delete();
      return $this->sendResponse($comment,'201');
  }
  

}