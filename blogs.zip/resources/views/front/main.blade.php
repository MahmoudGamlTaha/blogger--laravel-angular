<!doctype html>
<html @lang('en')>
<head>
  @include('layout/head')
</head>

<body class="fixed-nav sticky-footer " id="page-top" >
     @include('layout/header')
     @include ('layout/menu')

<div class="container">
    @yield('content')
</div>

    @include('layout/footer')
    @include('partials/_script')

@yield('script')
  </body>
</html>