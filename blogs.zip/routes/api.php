<?php

use Illuminate\Http\Request;
use App\Http\Controllers\PostController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::middleware(['middeleware'=>['api:auth']], function(){

   
        
});
Route::middleware('auth:api')->group( function () {
    Route::post('/cpost', [
        'uses' => 'PostController@createPost',
        'middleware' => 'cors'
    ]);
    
    Route::delete('/dpost/{id}', [
        'uses' => 'PostController@deletePost'
    ]);
    Route::get('lposts',
    [ 'uses'=>'PostController@postList']);
    //////////////////////////////////////////
});
Route::resource('posts','PostController',[
    'only'=>['postList']
]);

Route::post('/articles', [
    'uses' => 'PostController@createPost',
    'middleware' => 'cors'
]);

Route::get('articles',
[ 'uses'=>'PostController@postList']);

Route::get('tags',
[ 'uses'=>'CategoryController@CategoryList']);

Route::get('cats',
['uses'=>'CategoryController@Categories']);

Route::get('/articles/{id}', [
    'uses' => 'PostController@postDetail'
]);

Route::post('/users/login', 'Auth\RegisterController@loginX');
Route::post('/users/user', 'Auth\RegisterController@getCurrentUser');
Route::post('/users/register', 'Auth\RegisterController@register');
Route::post('/articles/{id}/comment','CommentController@addcomment');
Route::get('articles/{id}/comments','CommentController@getComments');
Route::delete('articles/{id}/comments/{comment}','CommentController@deleteComment');
Route::put('/articles/{id}', [
    'uses' => 'PostController@editPost'
]);
